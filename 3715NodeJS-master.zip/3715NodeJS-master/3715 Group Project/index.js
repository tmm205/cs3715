var server = require("./server");
var router = require("./router");
var requestHandlers = require("./requestHandlers");

var handle = {};

handle["/"] = requestHandlers.index;
handle["/index"] = requestHandlers.index;
handle["/post"] = requestHandlers.post;
handle["/404"] = requestHandlers.error404;

server.start(router.route, handle);