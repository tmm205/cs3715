Group project for 3715

Run index.js
